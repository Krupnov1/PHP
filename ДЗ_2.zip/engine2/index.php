<?php

//TODO соберите страницу about полностью вместе с меню.

function renderTemlate($page) {
    ob_start();
    include  "templates/" . $page . ".php";
    return ob_get_clean();
}

$main = renderTemlate('main');
$menu = renderTemlate('$menu');
$about = renderTemlate('$about');


echo renderTemlate('main');
echo renderTemlate('menu');
echo renderTemlate('about');